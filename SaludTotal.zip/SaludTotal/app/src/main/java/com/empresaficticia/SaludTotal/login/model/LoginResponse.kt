package com.empresaficticia.SaludTotal.login.model

data class LoginResponse(
    val Token: String,
    val email: String
)