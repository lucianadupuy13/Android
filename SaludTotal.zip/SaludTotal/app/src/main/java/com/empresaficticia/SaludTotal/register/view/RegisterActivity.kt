package com.empresaficticia.SaludTotal.register.view

class RegisterActivity {
}