package com.empresaficticia.SaludTotal.home.viewmodel

class HomeViewModel {
}