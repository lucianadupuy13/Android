package com.empresaficticia.SaludTotal.login.model

data class LoginRequest(
    val email: String,
    val password: String
)