package com.empresaficticia.SaludTotal.register.viewmodel

class RegisterViewModel {
}