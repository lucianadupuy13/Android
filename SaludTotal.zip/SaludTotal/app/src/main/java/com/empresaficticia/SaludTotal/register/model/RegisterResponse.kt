package com.empresaficticia.SaludTotal.register.model

class RegisterResponse {
}