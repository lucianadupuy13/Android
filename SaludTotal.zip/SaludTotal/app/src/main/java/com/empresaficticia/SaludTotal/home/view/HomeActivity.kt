package com.empresaficticia.SaludTotal.home.view

class HomeActivity {
}